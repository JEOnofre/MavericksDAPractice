package TestCases;

import java.io.IOException;
import java.util.ArrayList;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.pages.FreeStyle;

import Utilities.Action;
import Utilities.Browser;
import Utilities.DriverHandler;
import Utilities.ExecuteAction;
import Utilities.FileInputReader;
import Utilities.GlobalVals;

public class FreeStyleTestCase3 implements GlobalVals {

	public static String description;

	public FreeStyleTestCase3(String testCaseName){
			
			this.description = testCaseName;
		}
		
		public static void Execute(Browser browser) throws InterruptedException, IOException 
		{	
	
			// Read Input Data from CSV File
						FileInputReader input = new FileInputReader();
			    	
						//Extract Data needed from CSV Opened File
						
						ArrayList<String[]> a =	input.ReadFromCSV();
						
						String url,text,user,pass = "";
						url = a.get(5)[1];
						text = a.get(4)[2];
						user = a.get(4)[13];
						pass = a.get(4)[14];
						
			
			
	//*****************************************************************//
	/////////////////////// TEST CASE 3 /////////////////////////////////
	//*****************************************************************//
			
			
			ExtentReports extent;
			
			extent = newReport;
			
			
			ExtentTest testF2 = extent.createTest(description);
			
			FreeStyle free = new FreeStyle();
			
			
			testF2.log(Status.INFO, "Start of the Test Case");
			
			
			DriverHandler.Start(browser);
			
			testF2.log(Status.INFO, "Browser started");
			
			testF2.log(Status.INFO, "Maximizing Browser's Window");
			
			DriverHandler.driver.manage().window().maximize();
			
			try {
				ExecuteAction.Action(Action.navigate, null,null,null,null, "https://" + url,testF2,extent);
			} catch (Exception e) {
				testF2.log(Status.FAIL,"Couldnt navigate to the Site || " + e);
			}

			try {
				ExecuteAction.Action(Action.moveToHover, free.Download(),free.ClientDownload(),null,null, "Client Download Section",testF2,extent);
			} catch (Exception e) {
				testF2.log(Status.FAIL,"Couldnt click on the element || " + e);
			}
			
			Thread.sleep(3000);
			
			try {
				ExecuteAction.Action(Action.click, free.ClientDownloadLink(),null,null,null, "Download Game ",testF2,extent);
			} catch (Exception e) {
				testF2.log(Status.FAIL,"Couldnt click on the Download Game Link || " + e);
			}
			
			Thread.sleep(3000);
			
			ExecuteAction.Action(Action.quit, null,null,null,null, "",testF2,extent);
			
			
			testF2.log(Status.INFO, "Test Case Ended");
			
			extent.flush();
			
			
			
			
			
		}
}
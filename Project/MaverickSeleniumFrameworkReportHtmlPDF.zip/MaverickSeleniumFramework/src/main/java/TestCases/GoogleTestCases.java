	package TestCases;
	import java.io.IOException;
	import java.util.ArrayList;

	import com.aventstack.extentreports.ExtentReports;
	import com.aventstack.extentreports.ExtentTest;
	import com.aventstack.extentreports.Status;
	import com.aventstack.extentreports.reporter.ExtentSparkReporter;
	import com.pages.*;

	import Utilities.Action;
	import Utilities.Browser;

	import Utilities.DriverHandler;
	import Utilities.ExecuteAction;
	import Utilities.FileInputReader;
	import Utilities.GenerateReport;
	import Utilities.GlobalVals;


	
	public class GoogleTestCases implements GlobalVals {
		
		public static String description;

	public GoogleTestCases(String testCaseName){
			
			this.description = testCaseName;
		}
		
		public static void Execute(Browser browser) throws InterruptedException, IOException 
		{		
			
			
				// Read Input Data from CSV File
				FileInputReader input = new FileInputReader();
	    	
				//Extract Data needed from CSV Opened File
				
				ArrayList<String[]> a =	input.ReadFromCSV();
				String url,text = "";
				url = a.get(1)[1];
				text = a.get(1)[2];
				
				
				
				
				//Start Instance to generate a new Report
				ExtentReports extent;
				
				extent = newReport;
				
				
				System.out.println("\n------AQUI VEMOS EL EXTENT-----\n");
				System.out.println(extent);
				System.out.println("\n------AQUI VEMOS EL EXTENT-----\n");
				
				
				//*****************************************************************//
				/////////////////////// TEST CASE 1 /////////////////////////////////
				//*****************************************************************//
				
				ExtentTest test1 = extent.createTest(description);
				
				WebPage1 google = new WebPage1();
				
				test1.log(Status.INFO, "Start of the Test Case");
				
				
				DriverHandler.Start(browser);
				
				test1.log(Status.INFO, "Browser started");
				
				ExecuteAction.Action(Action.navigate, null,null,null,null, "https://" + url,test1,extent);

				ExecuteAction.Action(Action.click, google.txtSearchBox(),null,null,null, "Search bar",test1,extent);
				
				ExecuteAction.Action(Action.type, google.txtSearchBox(),null,null,"Hexaware", text,test1,extent);
				
				//test1.log(Status.INFO, "Waiting for 3 Seconds");
				Thread.sleep(5000);
				
				ExecuteAction.Action(Action.quit, null,null,null,null, "",test1,extent);
				
				
				test1.log(Status.INFO, "Test Case Ended");
				
				extent.flush();
				
			

		}
	}
	


package TestCases;

import java.io.IOException;
import java.util.ArrayList;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import Utilities.Action;
import Utilities.Browser;
import Utilities.DriverHandler;
import Utilities.ExecuteAction;
import Utilities.FileInputReader;
import Utilities.GenerateReport;

import com.pages.*;
import Utilities.GlobalVals;
public class TestCase2 implements GlobalVals {

	public static String description;

	public TestCase2(String testCaseName){
			
			this.description = testCaseName;
		}
		
		public static void Execute(Browser browser) throws InterruptedException, IOException 
		{	
	
			
			// Read Input Data from CSV File
			FileInputReader input = new FileInputReader();
    	
			//Extract Data needed from CSV Opened File
			
			ArrayList<String[]> a =	input.ReadFromCSV();
			String url,text = "";
			url = a.get(1)[1];
			text = a.get(1)[2];
			
	//*****************************************************************//
	/////////////////////// TEST CASE 2 /////////////////////////////////
	//*****************************************************************//
	
	
	ExtentReports extent;
	
	extent = newReport;
	
	System.out.println("\n------AQUI VEMOS EL EXTENT-----\n");
	System.out.println(extent);
	System.out.println("\n------AQUI VEMOS EL EXTENT-----\n");
	
	ExtentTest test2 = extent.createTest(description);
	
	WebPage1 google = new WebPage1();
	
	test2.log(Status.INFO, "Start of the Test Case");
	
	
	DriverHandler.Start(browser);
	
	test2.log(Status.INFO, "Browser started");
	
	test2.log(Status.WARNING, "Maximizing Window");
	
	DriverHandler.driver.manage().window().maximize();
	
	try {
		ExecuteAction.Action(Action.navigate, null,null,null,null, "https://" + url,test2,extent);
	} catch (Exception e) {
		test2.log(Status.FAIL,"Couldnt click on the element" + e);
	}
	
	
	try {
		ExecuteAction.Action(Action.click, google.txtSearchBox(),null,null,null, "Search bar",test2,extent);
	} catch (Exception e) {
		test2.log(Status.FAIL,"Couldnt click on the element" + e);
	}
	
	try {
		ExecuteAction.Action(Action.type, google.txtSearchBox(),null,null,"Hexaware", text,test2,extent);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		test2.log(Status.FAIL,"Couldnt click on the element" + e);
	}
	
	try {
		ExecuteAction.Action(Action.pressKey,google.txtSearchBox(), null, null, url, text, test2, extent);
	} catch (Exception e) {
		test2.log(Status.FAIL,"Couldnt click on the element" + e);
	}
	
	Thread.sleep(3000);
	
	try {
		ExecuteAction.Action(Action.click, google.PageNum(), null, null, "Link on page", null, test2,extent);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		test2.log(Status.FAIL,"Couldnt click on the element" + e);
	}
	
	Thread.sleep(3000);
	
	try {
		ExecuteAction.Action(Action.click, google.txtSearchBox(),null,null,null, "Search bar",test2,extent);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		test2.log(Status.FAIL, e);
	}
	
	
	//test1.log(Status.INFO, "Waiting for 3 Seconds");
	Thread.sleep(3000);
	
	ExecuteAction.Action(Action.quit, null,null,null,null, "",test2,extent);
	
	
	test2.log(Status.INFO, "Test Case Ended");
	
	extent.flush();
	
		}
	
}

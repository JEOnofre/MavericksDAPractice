package Utilities;

public enum Browser {
	Chrome,
	InternetExplorer,
	FireFox
	
}

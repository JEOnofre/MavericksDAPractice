package Utilities;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class ExecuteAction {
	
	public ExecuteAction() 
	{
		
	}
	public static void Action(Action action, WebElement element,WebElement hoverMove,WaitCommand com, String time, String value, ExtentTest test, ExtentReports extent) 
	{
		WebDriver driver = DriverHandler.driver;
		Actions moveAction = new Actions(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		if(driver != null) {
		switch(action) 
		{
		case click:
			try {
				element.click();
				test.log(Status.PASS, "Successfully clicked on " + value);
				System.out.println("=============>Succesfully clicked<=============");
			} catch (Exception e) {
				test.fail("Cant be able to click on the element " + e.getMessage());
				//test.log(Status.FAIL, "Cant be able to click on the element " + e.getMessage());
				extent.flush();
				System.out.println("=============>Failed: "+ e.getMessage()+"<=============");
			}	
			break;
		case type:
			try {
				element.sendKeys(value);
				test.log(Status.PASS, "Successfully typed " + "'"+ value +"'");
				System.out.println("=============>Succesfully Typed: "+ value+"<=============");
			} catch (Exception e) {
				System.out.println("=============>Failed: "+ e.getMessage()+"<=============");
			}
			break;
		case navigate:
			try {
				driver.navigate().to(value);
				test.log(Status.PASS, "Successfully navigated to " + value);
				System.out.println("=============>Succesfully Navigated to: "+ value+"<=============");
			} catch (Exception e) {
				test.log(Status.FAIL, "Cannot Navigate to the WebPage " + e.getMessage());
				System.out.println("=============>Failed: "+ e.getMessage()+"<=============");
			}
			break;
		case implicitWait:
			try {
				driver.manage().timeouts().implicitlyWait(Long.parseLong(value), TimeUnit.SECONDS);		
				System.out.println("=============>Succesfully Waited for: "+ value+" seconds<=============");
			} catch (NumberFormatException e) {
				System.out.println("=============>Failed: "+ e.getMessage()+"<=============");
			}			
			break;
		case quit:
			try {
				driver.quit();
				System.out.println("=============>Succesfully Closed<=============");
			} catch (Exception e) {
				System.out.println("=============>Failed: "+ e.getMessage()+"<=============");
			}
			break;
		case submit:
			try {
				element.submit();
				System.out.println("=============>Succesfully Submit<=============");
			} catch (Exception e) {
				System.out.println("=============>Failed: "+ e.getMessage()+"<=============");
			}
			break;
		case moveToHover:
			try {
	    		

				moveAction.moveToElement(element).moveToElement(hoverMove).click().build().perform();
				
				
				System.out.println("=============>Succesfully Moved To Element<=============");
				
			} catch (Exception e) {
				System.out.println("=============>Failed BAD: "+ e.getMessage()+"<=============");
			}
		case moveTo:
			try {
	    		
				
				
				moveAction.moveToElement(element);
				
				
				System.out.println("=============>Succesfully Moved To Element<=============");
				
			} catch (Exception e) {
				System.out.println("=============>Failed: "+ e.getMessage()+"<=============");
			}
		case explicitWait:
			try {
				
				int newTime = Integer.parseInt(time);
				
				ExecuteAction.ExecuteExplicitWait(driver, com, newTime, value);
				
				test.log(Status.PASS, "Succesfully waited for expected " + value);
				
				
				System.out.println("=============>Succesfully Waited For The Element<=============");
			}
			catch (Exception e){
				System.out.println("=============>Failed: "+ e.getMessage()+"<=============");
			}
			
		case getAttribute:
			try {
				
				
				
				
				
			}
			catch (Exception e) {
				
				
			}
				
		case makevisible:
			try {
				
				js.executeScript("arguments[0].click();",element);
				
				System.out.println("=============>Succesfully Scrolled<=============");
				test.log(Status.INFO, "Element is Visible" + value);
			}
			catch (Exception e) {
				
				System.out.println("=============>Failed: "+ e.getMessage()+"<=============");
			}
			
		case scroll:
			try {
				
				js.executeScript("window.scrollBy(0,300)");
				System.out.println("=============>Succesfully Scrolled<=============");
				test.log(Status.INFO, "Scrolled" + value);
			}
			catch (Exception e) {
				
				System.out.println("=============>Failed: "+ e.getMessage()+"<=============");
			}
			
			
		case pressKey:
			
			try {
				element.sendKeys(Keys.ENTER);
				test.log(Status.PASS, "Successfully entered on " + value);
				System.out.println("=============>Succesfully Waited For The Element<=============");
			} catch (Exception e) {
				
				System.out.println("=============>Failed: "+ e.getMessage()+"<=============");
			}
		
			
		}
		
		
		}else 
		{
			System.out.println("=============>Driver was not succesfully initiaded, skipping step.<=============");
		}
	}
			
		
	
		public static void ExecuteExplicitWait(WebDriver driver,WaitCommand command ,int time, String Condition) {
				
		
				WebDriverWait wait = new WebDriverWait(driver, time);
				//wait.until(ExpectedConditions.)
				
				if(driver != null) {
					switch(command) 
					{
					case titleIs:
						try {
							wait.until(ExpectedConditions.titleIs(Condition));
							
							System.out.println("=============>Succesfully Waited for<=============");
							System.out.println("=============>Condition<=============");
						} catch (Exception e) {
							System.out.println("=============>Failed: "+ e.getMessage()+"<=============");
						}	
						break;
					}
					}else 
					{
						System.out.println("=============>Driver was not succesfully initiaded, skipping step.<=============");
					}
				
				
			}

}
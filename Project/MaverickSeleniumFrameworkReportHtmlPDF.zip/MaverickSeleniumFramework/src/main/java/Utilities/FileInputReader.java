package Utilities;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class FileInputReader {
	
	public ArrayList<String[]> ReadFromCSV() throws IOException{
		
		BufferedReader bufferLectura = null;
		ArrayList<String[]> newArry = new ArrayList<String[]>();
		try {
			
			bufferLectura = new BufferedReader(new FileReader("C:\\Users\\Eduardo-PC\\Desktop\\MavericksDAPractice\\test.csv"));
			
			String linea = bufferLectura.readLine();
			
			
			while(linea != null) {
				
				String[]campos = linea.split(",");
				newArry.add(campos);
				linea = bufferLectura.readLine();
				System.out.println(Arrays.toString(campos));
				
			}
			
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		finally {
			  // Cierro el buffer de lectura
			  if (bufferLectura != null) {
			   try {
			    bufferLectura.close();
			   } 
			   catch (IOException e) {
			    e.printStackTrace();
			   }
			  }
			 }
		
		return newArry;
	}
	
	
	
	
	public void ReadFromXLS() throws EncryptedDocumentException, IOException {
		
		File f = new File("C:\\Users\\Eduardo-PC\\Desktop\\MavericksDAPractice\\test1.xlsx");
		
		InputStream input = new FileInputStream(f);
		
		Workbook book = WorkbookFactory.create(input);
		
		Sheet sheet = book.getSheetAt(0);
		
		
	    int iRow = 0;
		Row row = sheet.getRow(iRow); //En qué fila empezar ya dependerá también de si tenemos, por ejemplo, el título de cada columna en la primera fila
	      while(row!=null) 
	      {
	          Cell cell = row.getCell(1);  
	          String value = cell.getStringCellValue();
	          System.out.println("Valor de la celda es " + value);
	          iRow++;  
	          row = sheet.getRow(iRow);
	      }
		
		
		
		
		
	}
	
}

package Utilities;

import java.io.File;
import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.*;
import com.aventstack.extentreports.reporter.configuration.InteractiveReporterConfig.InteractiveReporterConfigBuilder;

import tech.grasshopper.reporter.ExtentPDFReporter;
public class GenerateReport {


	
	public static ExtentReports GenerateReport() {
		
		
		
		ExtentReports extent = new ExtentReports();
		ExtentSparkReporter spark = new ExtentSparkReporter("C:\\Users\\Eduardo-PC\\Desktop\\MavericksDAPractice\\TestReport.html");
		ExtentPDFReporter pdf = new ExtentPDFReporter("C:\\Users\\Eduardo-PC\\Desktop\\MavericksDAPractice\\TestReport.pdf");
		spark.config().setTheme(Theme.DARK);
		spark.config().setDocumentTitle("Hexaware Mavericks Test Reports");
		pdf.config().setReportName("Hexaware Mavericks Test Reports");
		extent.attachReporter(spark);
		extent.attachReporter(pdf);
		
		
		return extent;
		
		
	}
	
	
	
}

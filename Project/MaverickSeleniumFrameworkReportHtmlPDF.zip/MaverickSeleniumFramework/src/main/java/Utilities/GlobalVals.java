package Utilities;

import com.aventstack.extentreports.ExtentReports;

public interface GlobalVals {
	

	ExtentReports newReport = GenerateReport.GenerateReport();
	
	
}

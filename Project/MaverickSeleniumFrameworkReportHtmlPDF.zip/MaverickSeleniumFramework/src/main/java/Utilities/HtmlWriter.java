package Utilities;

import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class HtmlWriter {

	//Class to Create and write an Html Page
	public void WriteHtml() throws IOException {
		
		
		File f = new File("TestReport.html");
		BufferedWriter bw = new BufferedWriter(new FileWriter(f));
		
		bw.write("<html><body><h1> Test Cases Report </h1>");
		bw.write("<textarea cols=75 rows=10>");
		
		for(int i=0;i<20;i++) {
			
			bw.write("Repetimos texto aqui");
			
		}
		
		bw.write("</textarea");
		bw.write("<br>");
		bw.write("<br>");
		bw.write("<p>TEST CASES LOG</p>");
		bw.write("</body></html>");
		
		bw.close();
		
		Desktop.getDesktop().browse(f.toURI());
		
	}
	
}

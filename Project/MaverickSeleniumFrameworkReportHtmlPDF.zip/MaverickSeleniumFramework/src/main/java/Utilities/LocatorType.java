package Utilities;

public enum LocatorType {
	id,
	xpath,
	cssSelector,
	name,
	tagName, 
	className,
	linkText,
	partialLinkText
	
}



package Utilities;

public class Print {
	
	public Print() {}
		
		public static void TestCaseStart(String testCaseName) 
		{
			System.out.println("#####################################");
			System.out.println("#############"+testCaseName+"#############");
			System.out.println("#####################################");
		}
		public static void TestCaseEnd(String description) 
		{
			description = "";
			System.out.println("#####################################");
			System.out.println("#####################################");
			System.out.println("#####################################");
		}
}

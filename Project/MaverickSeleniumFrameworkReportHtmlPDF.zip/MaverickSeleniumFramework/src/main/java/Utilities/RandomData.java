package Utilities;

import java.util.Random;

public class RandomData {

	
	public String RandomName() {
		
		
		Random random = new Random();
		
		String A[] = new String[10];
		
		String myStr = "";
		for(int i=0;i<A.length;i++) {
			
		char randomChar = (char) (random.nextInt(26) + 'a');
		myStr = Character.toString(randomChar);
		A[i] = myStr;
		System.out.println(A[i]);
		}
		
		String value = String.join("", A);
		
		
		String Random_Email = value + "@gmail.com";
		
		return Random_Email;
		
		
	}
	
	
}

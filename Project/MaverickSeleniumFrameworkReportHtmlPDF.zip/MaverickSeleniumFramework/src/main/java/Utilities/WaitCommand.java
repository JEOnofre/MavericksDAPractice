package Utilities;

public enum WaitCommand {

	titleIs
	
}

package com.main.app;
import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import TestCases.FreeStyleTestCase1;
import TestCases.FreeStyleTestCase2;
import TestCases.FreeStyleTestCase3;
import TestCases.FreeStyleTestCase4;
import TestCases.FreeStyleTestCase5;
import TestCases.GoogleTestCases;
import TestCases.TestCase2;
import Utilities.HtmlWriter;
import Utilities.Browser;
import Utilities.FileInputReader;

public class App {

	
	public static void main(String[] args) throws IOException, InterruptedException {
	
		/*GoogleTestCases.description = "Google search of Hexaware";
		GoogleTestCases.Execute(Browser.Chrome);
		
		TestCase2.description = "Google MX Search of Hexaware and More";
		TestCase2.Execute(Browser.Chrome);
		*/
		
		FreeStyleTestCase1.description = "Sign in into FreeStyle 2 Game Website";
		FreeStyleTestCase1.Execute(Browser.Chrome);
		
		
		FreeStyleTestCase2.description = "Play Music from Online Player";
		FreeStyleTestCase2.Execute(Browser.Chrome);
		
		FreeStyleTestCase3.description = "Download Client Application Game From Website";
		FreeStyleTestCase3.Execute(Browser.Chrome);
		
		FreeStyleTestCase4.description = "View Wallpaper Images from Multimedia Section";
		FreeStyleTestCase4.Execute(Browser.Chrome);
		
		FreeStyleTestCase5.description = "Move through Banner Elements";
		FreeStyleTestCase5.Execute(Browser.Chrome);
		
		
		
		File htmlFile = new File("C:\\Users\\Eduardo-PC\\Desktop\\MavericksDAPractice\\TestReport.html");
		Desktop.getDesktop().browse(htmlFile.toURI());
		
		
	}

}

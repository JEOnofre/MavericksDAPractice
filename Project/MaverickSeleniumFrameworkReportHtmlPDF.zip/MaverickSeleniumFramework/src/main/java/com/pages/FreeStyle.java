package com.pages;

import org.openqa.selenium.WebElement;

import Utilities.LocatorType;
import Utilities.Locators;
import java.math.*;
import java.util.Random;

public class FreeStyle {

	
	public FreeStyle() {}
	
	public WebElement SignInButton() {
		
		Locators Locator = new Locators(LocatorType.cssSelector,"div[class=\"text_wrap\"]>ul>li>a");
		
		return Locator.element;
	}
	
	
	public WebElement InputEmail() {
		
		Locators Locator = new Locators(LocatorType.id,"sign_in_email");
		
		return Locator.element;
		
	}
	
	public WebElement InputPass() {
		
		Locators Locator = new Locators(LocatorType.id,"sign_in_password");
		
		return Locator.element;
		
	}
	
	
	public WebElement ConfirmSignIn() {
		

		Locators Locator = new Locators(LocatorType.id,"sign_in_confirm");
		
		return Locator.element;
		
		
	}
	
	
	
	public WebElement Download() {
		

		Locators Locator = new Locators(LocatorType.xpath,"//*[@id=\"nav\"]/ul/li[4]/h2/a");
		
		return Locator.element;
		
		
	}
	
	public WebElement MultimediaDownload() {
		

		Locators Locator = new Locators(LocatorType.cssSelector,"div[id=\"nav\"]>ul>li[class=nav4]>ul>li>h3>a[href=\"/download/multimedia\"]");
		
		return Locator.element;
		
		
	}
	
	public WebElement ClientDownload() {
		

		Locators Locator = new Locators(LocatorType.xpath,"//*[@id=\"nav\"]/ul/li[4]/ul/li[1]/h3/a");
		
		return Locator.element;
		
		
	}
	
	
	
	public WebElement PlayMusic1() {
		
		Locators Locator = new Locators(LocatorType.cssSelector,"div[id=\"mCSB_1\"]>div[id=\"mCSB_1_container\"]>ul>li>a");
		
		return Locator.element;
		
	}
	
	
	public WebElement ClientDownloadLink() {
		
		Locators Locator = new Locators(LocatorType.cssSelector,"div[class=\"luncher_down_con\"]>a");
		
		return Locator.element;
		
	}
	
	
	public WebElement PlayMusic2() {
		
		Locators Locator = new Locators(LocatorType.xpath,"//div/div[@class=\"bgm_list\"]/div/div/div/ul/li[6]/a");
		
		return Locator.element;
		
	}
	
	
	
	public WebElement StopMusic() {
		
		Locators Locator = new Locators(LocatorType.xpath,"//div[@id=\"wrapper\"]/a[@id=\"play\"]");  
		
		return Locator.element;
		
	}
	
	

	public WebElement OverImage() {
		
		Locators Locator = new Locators(LocatorType.cssSelector,"div[class=\"wallpaper_con\"]>ul>li"); 
		
		return Locator.element;
		
	}
	
	
	public WebElement ChooseWallpaper() {
		
		
		Locators Locator = new Locators(LocatorType.xpath,"//div[@class=\"wallpaper_con\"]/ul/li[1]/a/span[2]/img[1]"); 
		
		return Locator.element;
		
	}
	
	
	public WebElement NextWallpaper() {
		
		
		Locators Locator = new Locators(LocatorType.xpath,"//div[@class=\"wallpaper_screen_bottom\"]/a[2]/img"); 
		
		return Locator.element;
		
	}
	
	public WebElement PreviousWallpaper() {
		
		
		Locators Locator = new Locators(LocatorType.xpath,"//div[@class=\"wallpaper_screen_bottom\"]/a[1]/img"); 
		
		return Locator.element;
		
	}
	
	
	public WebElement CloseWallpaper() {
		
		
		Locators Locator = new Locators(LocatorType.xpath,"//div[@id=\"wallpaper_layer\"]/a/img"); 
		
		return Locator.element;
		
	}
	
	
	public WebElement Banner() {
		
		
		String []A = new String[10];
		
		A[0] = "//div[@class=\"main_banner\"]/ul[2]/li[1]/a";
		A[1] = "//div[@class=\"main_banner\"]/ul[2]/li[2]/a";
		A[2] = "//div[@class=\"main_banner\"]/ul[2]/li[3]/a";
		A[3] = "//div[@class=\"main_banner\"]/ul[2]/li[4]/a";
		A[4] = "//div[@class=\"main_banner\"]/ul[2]/li[5]/a";
		A[5] = "//div[@class=\"main_banner\"]/ul[2]/li[6]/a";
		A[6] = "//div[@class=\"main_banner\"]/ul[2]/li[7]/a";
		A[7] = "//div[@class=\"main_banner\"]/ul[2]/li[8]/a";
		A[8] = "//div[@class=\"main_banner\"]/ul[2]/li[9]/a";
		A[9] = "//div[@class=\"main_banner\"]/ul[2]/li[10]/a";
		
		Random random = new Random();
		
		String BanPos = A[random.nextInt(10)];
		
		
		Locators Locator = new Locators(LocatorType.xpath,BanPos); 
		
		return Locator.element;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

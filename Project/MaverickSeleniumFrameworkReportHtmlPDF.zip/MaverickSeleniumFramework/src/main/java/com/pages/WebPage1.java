package com.pages;

import org.openqa.selenium.WebElement;

import Utilities.LocatorType;
import Utilities.Locators;

public class WebPage1 {

	
	public WebPage1() 
	{
		
	}
	public WebElement txtSearchBox() 
	{
		Locators locators = new Locators(LocatorType.name, "q");
		
		return Locators.element;
		
	}
	
	public WebElement PageNum() 
	{
		Locators locators = new Locators(LocatorType.xpath,"//*[@id=\"rso\"]/div[1]/div/div/div[1]/div/a/h3");
		
		return Locators.element;
		
	}
	
	
	
	
}
